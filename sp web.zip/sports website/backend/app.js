
const express = require('express');
const app = express();

const cors = require("cors");
app.use(cors());

const bodyParser = require("body-parser");
app.use(bodyParser.json());

const mongoose = require('mongoose')
mongoose.connect('mongodb+srv://samkowshik02:3Ddr6PG5JdGFBP0p@cluster0.hchfytv.mongodb.net/Cluster0?retryWrites=true&w=majority&appName=Cluster0')
.then(() => app.listen(5000))
.then(() =>console.log("Connected to Database & Listining to localhost 5000"))
.catch((err) => console.log(err));

app.use("/api", (req, res, next)=>{
    res.send("hi hello")
})
