import './App.css';
import HeaderBar from './components/HeaderNav';
import HomePage from './pages/HomePage';
import CoOrdRegiPage from './pages/CoOrdRegi';
import StudentRegiPage from './pages/StudentRegi';
import CoOrdLoginPage from './pages/CoOrdLogin';
import UpCmgEventsPage from './pages/UpComingEvents';
import PresentEventsPage from './pages/PresentEvents';
import PastEventsPage from './pages/PastEvents';
import GalleryPage from './pages/Gallery';
import ContactPage from './pages/ContactUs';
import {BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <HeaderBar/>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<HomePage/>}/>
          <Route path='/co-ordinator-registration' element={<CoOrdRegiPage/>}/>
          <Route path='/student-registration' element={<StudentRegiPage/>}/>
          <Route path='/co-ordinator-login' element={<CoOrdLoginPage/>}/>
          <Route path='/upcoming-events' element={<UpCmgEventsPage/>}/>
          <Route path='/present-events' element={<PresentEventsPage/>}/>
          <Route path='/past-events' element={<PastEventsPage/>}/>
          <Route path='/contact-us' element={<ContactPage/>}/>
          <Route path='/gallery' element={<GalleryPage/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
