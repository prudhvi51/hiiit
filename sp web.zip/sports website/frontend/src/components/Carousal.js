import Carousel from 'react-bootstrap/Carousel';
import './Carousal.css';

const ImageCarousel = () => {
    let ImageUrlArray = [ "https://aec.edu.in/Facilities/Sports/4.jpg",
                          "https://aec.edu.in/Facilities/Sports/5.jpg", 
                          "https://aec.edu.in/Facilities/Sports/6.jpg"];
  return (
        <Carousel>
          {ImageUrlArray.map(url=>{
            return(
            <Carousel.Item interval={1000}>
                <img className="d-block w-100 " src={url}  alt=""/>
            </Carousel.Item>
            );
          })}
        </Carousel>
      );
};

export default ImageCarousel;
