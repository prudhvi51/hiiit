import './CoOrdForm.css'
import bgimg from '../Assests/registrationbackground.jpg';

const CoOrdinatorFormComp = () =>{
    const handelSub= (e) =>{
        e.preventDefault();
    }

    return<> 
        <div className='crdFormDiv'>
            <div className='crdFormBgDiv'> <img src={bgimg} alt=''/></div>
            <form className="CoordinatorForm mt-5" onSubmit={handelSub}>
                <h2 >Register your college Here</h2>
                <div className="input">
                    <label> College Name: </label>
                    <input  type="text" required />
                </div>
                <div className="input">
                    <label> Co-ordinator Name : </label>
                    <input  type="text" required/>
                </div>
                <div className="input">
                    <label> Contact Number : </label>
                    <input  type="text" required/>
                </div>
                <div className="input">
                    <label> WhatsApp Number : </label>
                    <input  type="text" required/>
                </div>
                <div className="radio row ">
                    <label className="col-12 fs-6"> Select Gender</label>
                    <label className="col-12 "> <input type="radio" name="option"/>  Male </label>
                    <label className="col-12 "> <input type="radio" name="option"/> Female </label>
                </div>
                <input className="btn btn-lg px-5 py-1  btn-primary m-3" type="submit" value="Payment" />
            </form>
        </div>
    </>
}
export default CoOrdinatorFormComp