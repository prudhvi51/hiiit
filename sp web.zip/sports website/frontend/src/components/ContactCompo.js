import "./ContactComp.css";
import React, { useState } from 'react';
import img from '../Assests/contactbg.jpg';

const ContactUsComp = () => {
          const [name, setName] = useState({
            firstName: '',
           lastName: '',
          });
          const [email, setEmail] = useState('');
          const [message, setMessage] = useState('');
        
          const handleChange = (event) => {
            const { name, value } = event.target;
            if (name === 'firstName') {
              setName({ ...name, firstName: value });
            } else if (name === 'lastName') {
              setName({ ...name, lastName: value });
            } else if (name === 'email') {
              setEmail(value);
            } else if (name === 'message') {
              setMessage(value);
            }
          };
        
          const handleSubmit = (event) => {
            event.preventDefault();
            // Implement your logic for submitting the form data here
            console.log('Name:', name.firstName + ' ' + name.lastName );
            console.log('Email:', email);
            console.log('Message:', message);
            setName({ firstName: '', lastName: '' });
            setEmail('');
            setMessage('');
          };
  return (

    <div className="container"  >
      <div className='contactBgDiv'>
      <img src={img} alt="College Image"></img>
      </div>
      <h1 >Contact Us</h1>
      <div className="row">
      
      <div className="col-md-6">  
          <div className='card' >
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d61018.51604376694!2d82.0668!3d17.08941!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a378165aaaaaaab%3A0x481e8b12b4b80715!2sAditya%20Engineering%20College!5e0!3m2!1sen!2sus!4v1710676716803!5m2!1sen!2sus" 
          width="100%" height="500vh"  allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
          <div className='childcard'>
            <h4>Contact Information</h4>
            <p>123 Main Street</p>
            <p>City, State ZIP</p>
            <p>Phone: (123) 456-7890</p>
            <p>Email: example@example.com</p>
          </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className='card1'>
          
          <form onSubmit={handleSubmit}>
         <div className="form-group">
          <label htmlFor="firstName" style={{color:"black",fontSize:"20px"}}>TELL US YOUR NAME</label>
         <div className="name-inputs">
             <input
              type="text"
              className="form-control"
              id="firstName"
              placeholder="First name"
              name="firstName"
              value={name.firstName}
              onChange={handleChange}
              required
            />
            <br></br>
            <input
              type="text"
              className="form-control"
              id="lastName"
              placeholder="Last name"
              name="lastName"
              value={name.lastName}
              onChange={handleChange}
              required
            />
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="email" style={{color:"black",fontSize:"20px"}}>ENTER YOUR EMAIL</label>
          <input
            type="email"
            className="form-control"
            id="email"
            placeholder="Eg. example@email.com"
            name="email"
            value={email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="message" style={{color:"black",fontSize:"20px"}}>MESSAGE</label>
          <br/>
          <textarea
            className="form-control"
            id="message"
            rows="5"
            placeholder="Write us a message"
            name="message"
            value={message}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <br/>
        <button type="submit"className="btn btn-success" style={{color:"white",fontSize:"20px"}}>
          SEND MESSAGE
        </button>
      </form>
        </div>
        </div>
        </div>
      </div>
    
  );
};
export default ContactUsComp;
