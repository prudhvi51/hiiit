import React from 'react';
import { CiLinkedin } from "react-icons/ci";
import { FaInstagram } from "react-icons/fa";
import { CiYoutube } from "react-icons/ci";
import { FaPhoneAlt } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-dark text-light py-4">
      <div className='container'>
        <div className='row'>
          <div className='col-md'>
            <img className='w-75' src='https://aec.edu.in/logos/LOGO3.png' alt ='' />
          </div>
          <div className='col-md col-sm-12 mt-4'>
            <p className="text-center"> Aditya Engineering College © 2024 - All rights reserved.</p>
          </div>
          <div className='col-md mt-3'>
            <FaPhoneAlt className='fs-3 mx-1'/>
            <CiLinkedin className='fs-1 mx-1'/>
            <FaInstagram className='fs-2 mx-1'/>
            <CiYoutube className='fs-1 mx-1'/>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
