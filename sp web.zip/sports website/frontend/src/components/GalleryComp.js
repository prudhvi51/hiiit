import React from 'react';
import './GalleryComp.css'

const GalleryComp = () => {
  const images = [
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
      {src: "https://picsum.photos/450/200" },
  ];

  return (
    <div className="container">
      <div className="row row-cols-1 row-cols-sm-2 row-cols-lg-3 g-4">
        {images.map((image, ind) => (
          <div className="col " key={ind}>
            <img src={image.src} className="img-fluid border border-secondary rounded-4" alt='' />
          </div>
        ))}
      </div>
    </div>
  );
};

export default GalleryComp;
