import {Container, Nav, Navbar, NavDropdown} from 'react-bootstrap';

const HeaderBar = () =>{
    return <>
    <Navbar className="sticky-top bg-warning " expand="md" >
      <Container>
        
        <Navbar.Brand href="/"><img height={25} src='https://aec.edu.in/adityanew/images/logo.png' alt ='' /></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav"/>
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link  href="/">Home</Nav.Link>
            <NavDropdown title="Registrations" id="basic-nav-dropdown">
              <NavDropdown.Item className='text-center' href="/co-ordinator-registration"> Co-ordinator Registration </NavDropdown.Item>
              <NavDropdown.Item className='text-center' href="/student-registration"> Student Registration </NavDropdown.Item>
              <NavDropdown.Item className='text-center' href="/co-ordinator-login"> Co-ordinator login </NavDropdown.Item>
            </NavDropdown>
            <NavDropdown  title="Events">
              <NavDropdown.Item className='text-center' href="/upcoming-events"> Upcoming Events </NavDropdown.Item>
              <NavDropdown.Item className='text-center' href="/present-events"> Present Events </NavDropdown.Item>
              <NavDropdown.Item className='text-center' href="/past-events"> Past Events </NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="/gallery"> Gallery </Nav.Link>
            <Nav.Link href="/contact-us"> Contact Us </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </>
}
export default HeaderBar;