import './StudentForm.css'
import LiveScan from './liveScan';
import bgimg from '../Assests/registrationbackground.jpg';

import { useState } from 'react';
const StudentFormComp = () =>{
    const messDates = ["16-3-2024","17-3-2024","18-3-2024","19-3-2024"];
    const data = [  {"Block A": [ 102, 103]},
                    {"Block B": [201, 202, 203]}]

    const [selectedKey, setSelectedKey] = useState('');
    const [selectedValue, setSelectedValue] = useState('');
    const [livePhoto, setLivePhoto] = useState(null);
    const [declareForm, setDeclareForm] = useState(null);

    const handleKeyChange = (event) => {
        setSelectedKey(event.target.value);
    };
    const handleValueChange = (event) => {
        setSelectedValue(event.target.value);
    };
    const photoChange = (event) => {
        setLivePhoto(event.target.files[0]);
    };
    const declareChange = (event) => {
        setDeclareForm(event.target.files[0]);
    };

    const keys = data.map(obj => Object.keys(obj)[0]);
    const values = selectedKey && selectedKey!=="Select Block" ? data.find(obj => Object.keys(obj)[0] === selectedKey)[selectedKey] : [];
                      

    const handelSub= (e) =>{
        e.preventDefault();
        let boxArrays = document.querySelectorAll('.fooddiv input[type="checkbox"]');
        let checkedArray= [];
        boxArrays.forEach((ele, ind)=>{
            if(ele.checked)
            checkedArray.push(ind);
        })
        console.log(checkedArray, selectedKey, selectedValue, livePhoto, declareForm);
    }

    return<>
    <div className='stdFormDiv'>
        <div className='stdFormBgDiv'> <img src={bgimg} alt=''/></div>
        <h1 className='mt-3' >Hurry Up! Register Here</h1>
        <form className="studentForm" onSubmit={handelSub}>
            <h2> Basic Details</h2>
            <div className="input">
                <label> Name of the Student : </label>
                <input  type="text"  />
            </div>
            <div className="input">
                <label> Father / Mother's Name : </label>
                <input  type="text" />
            </div>
            <div className="input">
                <label> Date of Birth : </label>
                <input  type="text" />
            </div>
            <div className="input">
                <label> Highest Qualification : </label>
                <input  type="text" />
            </div>
            <div className="input">
                <label> Year of Qualification : </label>
                <input  type="text" />
            </div>
            
            <div className="input">
                <label> Present Year : </label>
                <input  type="text" />
            </div>
            <div className="input">
                <label> Branch Name : </label>
                <input  type="text" />
            </div>
            <div className="input">
                <label> Roll Number : </label>
                <input  type="text" />
            </div>
            <div className="input">
                <label> Course Duration years : </label>
                <input  type="number" />
            </div>
            <div className="input">
                <label> Participations in UG : </label>
                <input  type="number" />
            </div>
            <div className="input">
                <label> Participations in PG : </label>
                <input  type="number" />
            </div>
            <h2> Accomodation Details</h2>   
            <div className="input">
                <label> Transport Mode : </label>
                <input  type="text"/>
            </div>
            <div className="input">
                <label> Arrival Time : </label>
                <input  type="text"/>
            </div>

            <div>
                <label className='col-12 fs-4 text-center'> Accomodation </label>
                <select className='m-2' onChange={handleKeyChange}>
                    <option>Select Block</option>
                    {keys.map((key, index) => (
                    <option key={index} value={key}>{key}</option>
                    ))}
                </select>
                <select onChange={handleValueChange} disabled={!selectedKey}>
                    <option>Select Room</option>
                    {values.map((value, index) => (
                    <option key={index} value={value}>{value}</option>
                    ))}
                </select>
            </div>
            <div className="fooddiv row">
                <label className=' fs-4 text-center'> Food Menu </label>
                <div className='col-12'>
                    {messDates.map((ele, ind)=>{
                        return(<label key={ind} className='col-12' ><input type="checkbox" /> {ele} </label>);
                    })}
                </div>
            </div>
            <h2> Verification </h2>
            <div className="input">
                <label >Upload Declartion Form : </label>
                <input type="file" onChange={declareChange} />
            </div>
            <LiveScan/>
            <input className="btn btn-lg px-5 py-1  btn-primary m-3" type="submit" value="Register" />
        </form>
    </div>
    </>
}
export default StudentFormComp