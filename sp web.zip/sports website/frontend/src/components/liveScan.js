import React, { useEffect, useRef, useState } from 'react';
import Webcam from 'react-webcam';
import './liveScan.css';

function LiveScan() {
  const webcamRef = useRef(null);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [showWebcam, setShowWebcam] = useState(false); 
  const [captureButtonText, setCaptureButtonText] = useState('Capture');
  const [uploadButtonText, setUploadButtonText] = useState('Upload Live Photo');

  useEffect(() => {
    const getCameraAccess = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (webcamRef.current) {
          webcamRef.current.video.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        alert('Failed to access camera.');
      }
    };
  }, []);

  const handleUploadClick = () => {
    setShowWebcam(true);
    setUploadButtonText("Live Photo Uploded");
  };

  const handleCapture = () => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      setUploadedImage(imageSrc);
      setCaptureButtonText('Recapture');
    }
  };

  const handleUpload = async () => {
    setShowWebcam(false); 
    console.log(uploadedImage);
  };

  return (
    <>
        {!showWebcam && (
          <div>
            <button className="btn btn-sm btn-success" onClick={handleUploadClick}>{uploadButtonText}</button>
          </div>
        )}
        {showWebcam && ( // Show webcam only when showWebcam state is true
        <>
          <div>
            <Webcam
              audio={false}
              ref={webcamRef}
              screenshotFormat="image/jpeg"
              className="webcam"
            />
            <button className="capture-button" onClick={handleCapture}>
              {captureButtonText}
            </button>
          </div>
          <div className="image-container">
          {/* Render the uploaded image */}
          {uploadedImage && (
            <div>
              <img src={uploadedImage} alt="Uploaded" className="uploaded-image" />
              <button className="submit-button" onClick={handleUpload}>Submit Photo</button>
            </div>
          )}
        </div>
        </>
        )}
    </>
  );
}

export default LiveScan;
