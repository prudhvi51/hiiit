const CoOrdLoginPage = () =>{
    return<>
        <h1>Co-ordinator Login Page</h1>
    </>
}
export default CoOrdLoginPage