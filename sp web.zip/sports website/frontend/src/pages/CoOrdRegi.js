import CoOrdinatorFormComp from "../components/CoOrdForm";

const CoOrdRegiPage = () =>{
    return<>
        <CoOrdinatorFormComp/>
    </>
}

export default CoOrdRegiPage;