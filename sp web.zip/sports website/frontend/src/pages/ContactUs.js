import ContactUsComp from "../components/ContactCompo";

const ContactPage = () =>{
    return<>
        <ContactUsComp/>
    </>
}
export default ContactPage;