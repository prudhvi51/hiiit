import GalleryComp from "../components/GalleryComp"
const GalleryPage = () =>{
    return<>
        <h1>Welcome to the Gallery</h1>
        <GalleryComp/>
    </>
}
export default GalleryPage