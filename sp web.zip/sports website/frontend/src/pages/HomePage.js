import ImageCarousel from "../components/Carousal";
import Footer from "../components/Footer";

const HomePage = () =>{
    return<>
        <div className="container fs-5">
            <ImageCarousel/>
            <>
                <p className="mt-5">Securing fourteen successive Intercollegiate athletics championships from the affiliating university speaks volumes of Aditya’s commitment in delivering sporting excellence besides high academic standards. The institute treats athletics and extracurricular activities as essential components by integrating them on par with academics to enhance the holistic development of students. This results in the active participation and recognization of student’s talents. Sports and games, a very distinctive feature of maintaining its tradition with fervor, has made Aditya the homeland to outstanding sportsmen and players.
                    <br/>Demonstrating the sporting spirit, six specially trained coached and physical directors including exclusive female physical director for girls render systematic training with which the college has been winning laurels in sports and games in intramural and Inter University Competitions and open tournaments.</p>
                <div className="row mt-5">
                    <div className="col-md col-sm-12"> <img src="https://picsum.photos/250" alt=''/> </div>
                    <div className="col-md col-sm-12">
                        <p className="">
                            Sports Farewell is celebrated to honor the best performer in the previous years.
                            <br/>International day is conducted every year where students from different countries come and participate in various sports and games events.
                            <br/>Intramurals are conducted every year from December to March.
                            <br/>Exclusive events are conducted like APL – Aditya Premiere League, ACT – Aditya Cricket Tournament and AFL – Aditya Football League ,Chess Competition, Hand ball Tournament, Shuttle Badminton Tournament ,Kabaddi Tournament, Tennikoit Tournament, Throw ball Tournament, Volley ball Tournament, Table Tennis Tournament etc.
                        </p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md col-sm-12">
                        <p className="">
                            <br/>Various sports and games events are conducted on account of Women’s day, Sports day, Youth fest ‘Colors’, Campfire etc.
                            <br/>Our institution organizes the “CENTRAL ZONE MEN & WOMEN ATHLETICS MEET” in every academic year. This meet evidences the presence of nearly 60 colleges to take participation in this event proposed by JNTUK.
                            <br/>National sports day is conducted every year where all the students are encouraged to participate in various events.
                        </p>
                    </div>
                    <div className="col-md col-sm-12"> <img src="https://picsum.photos/251" alt=''/> </div>
                </div>
            </>
            <>
                <h1>Sports Facilities</h1>
                <div className="row">
                    <div className="col">
                        <ul className="list-unstyled">
                            <li>Athletic Track</li>
                            <li>Basket Ball Court</li>
                            <li>Cricket Field</li>
                            <li>Cricket Practice Net</li>
                        </ul>
                    </div>
                    <div className="col">
                        <ul className="list-unstyled">
                            <li>Foot Ball Court</li>
                            <li>Hand Ball Court</li>
                            <li>Kabaddi Court</li>
                            <li>Shuttle Badminton Court</li>
                        </ul>
                    </div>
                </div>
            </>
        </div>
        <Footer/>
    </>
}
export default HomePage;