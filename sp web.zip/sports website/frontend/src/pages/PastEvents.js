const PastEventsPage = () =>{
    return<>
        <h1>This is Past Events Page</h1>
    </>
}
export default PastEventsPage