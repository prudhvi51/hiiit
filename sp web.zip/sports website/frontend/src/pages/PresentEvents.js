const PresentEventsPage = () =>{
    return<>
        <h1>This is Present Events Page</h1>
    </>
}
export default PresentEventsPage