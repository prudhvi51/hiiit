import StudentFormComp from "../components/StudentForm";

const StudentRegiPage =() =>{
    return<>
        <StudentFormComp/>
    </>
}

export default StudentRegiPage