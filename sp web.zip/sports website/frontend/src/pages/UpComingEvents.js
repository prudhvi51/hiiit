const UpCmgEventsPage = () =>{
    return<>
        <h1>This is Upcoming Events Page</h1>
    </>
}
export default UpCmgEventsPage